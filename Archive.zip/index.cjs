import("./src/index.js")
  .then(({ default: server }) => {
    server.listen(8000, () => {
      console.log("Server running...");
    });
  })
  .catch((err) => {
    console.error("Error starting the application:", err);
  });
